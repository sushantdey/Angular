import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Product } from '../product';
import { ProductService } from 'src/app/services/product.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent{
  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService) {}
  addProductTitle:string='Add Product';
  message:string;
  errorMessage:string;
  productForm = new FormGroup({
    productName: new FormControl(''),
    productCode: new FormControl(''),
    releaseDate: new FormControl(''),
    description: new FormControl(''),
    price: new FormControl(''),
    starRating: new FormControl('')
  })
  onSubmit(): void{
    this.productService.acceptProductDetails(this.productForm).subscribe(
      message=>{
        this.message=message;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    );
    this.router.navigate(['/products']);
  }
  public navigateBack(): void{
    this.router.navigate(['/products']);
  }
  /*_productName:string='';
  _productCode:string='';
  _releaseDate:string='';
  _description:string='';
  _price:string='';
  _starRating:string='';
  constructor() {
    this._productName="";
    this._productCode="";
    this._releaseDate="";
    this._description="";
    this._price="";
    this._starRating="";
   }
  get ProductName(): string{
    return this._productName;
  }
  set ProductName(value: string){
    this._productName=value;
  }
  get ProductCode(): string{
    return this._productCode;
  }
  set ProductCode(value: string){
    this._productCode=value;
  }
  get ReleaseDate(): string{
    return this._releaseDate;
  }
  set ReleaseDate(value: string){
    this._releaseDate=value;
  }
  get Description(): string{
    return this._description;
  }
  set Description(value: string){
    this._description=value;
  }
  get Price(): string{
    return this._price;
  }
  set Price(value: string){
    this._price=value;
  }
  get StarRating(): string{
    return this._starRating;
  }
  set StarRating(value: string){
    this._starRating=value;
  }
  ngOnInit() {
  }*/

}

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Product } from '../products/product';
import { HttpErrorResponse } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  constructor(private httpClient: HttpClient) { }
  public getAllProductsDetail():Observable<Product[]>{
    return this.httpClient.get<Product[]>("http://localhost:8086/onlineShop/getAllProductDetails").pipe(catchError(this.handleError));
  }
  public getProductDetails(productId:number): Observable<Product>{
    let params = new HttpParams();
    params = params.set('productId',productId.toString());
    return this.httpClient.get<Product>("http://localhost:8086/onlineShop/getProductDetails",{params:params}).pipe(catchError(this.handleError));
  }
  public removeProductDetails(productId:number): Observable<string>{
    let params = new HttpParams();
    params = params.set('productId',productId.toString());
    return this.httpClient.get<string>("http://localhost:8086/onlineShop/removeProductDetails",{params:params}).pipe(catchError(this.handleError));
  }
  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error(`1 An ErrorEvent Occurred: `,error.error.message);
      return throwError(error.error.message);
    }
    else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(`2 Backend returned code ${error.status}, body was: ${error.message}`);
    }
    else if(error instanceof TypeError){
      console.error(`3 TypeError has occurred ${error.message}, body was ${error.stack}`);
      return throwError(`3 TypeError has occurred ${error.message}, body was ${error.stack}`);
    }
  }
}

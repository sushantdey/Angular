import {  Component, OnInit,Input,  Output ,EventEmitter} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';
import { Product } from '../products/product';
@Component({
  selector: 'app-trash-alt',
  templateUrl: './trash-alt.component.html',
  styleUrls: ['./trash-alt.component.css']
})
export class TrashAltComponent {
  errorMessage: string;
  message: string;
  constructor(private route:ActivatedRoute,private router:Router,private productService:ProductService) { }
  ngOnInit() {
    
  }
  @Input() productId: number;

  @Output() trashClicked: EventEmitter<string> = new EventEmitter<string>();
  
  onClick(): void{
    this.productService.removeProductDetails(this.productId).subscribe(
      message=>{
        this.message=message;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    );
    window.location.reload();
    this.trashClicked.emit(`Product with Id ${this.productId} successfully deleted!`);
  }
}

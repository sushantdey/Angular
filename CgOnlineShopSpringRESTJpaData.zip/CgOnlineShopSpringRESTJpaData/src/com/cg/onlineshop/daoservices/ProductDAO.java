package com.cg.onlineshop.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import com.cg.onlineshop.beans.Product;
@Component("productDAO")
public interface ProductDAO extends JpaRepository<Product, Integer>{

}
